<?php

return array(
    'main' =>
    array(
        'host' => '127.0.0.1',
        'num' => '3',
        'port' => '6479',
        'pwd' => '123456',
        'pre' => 'ng169_',
        'charset' => 'utf8',
        'timeout' => '604800' //过期时间一周
    )

);
