<?php

return array(
        'ip'=>'192.168.10.5',
        'port'=>'4563',
        'pwd'=>'123456',
);
