<?php
//全局参数类

return array(
	'task' => [
        'share_coin' => '20',
        'read_coin'  => '50',
        'answer_coin' => '50',
        'advert_coin' => '20',
        'invite_coin' => '500',
        'day_share' => 1,
        'day_read'  => 2,
        'invite_task' => 3,
        'agent_task'  =>  4,
        'day_advert'  =>  5,
        'sign_task'  => 6
    ],
);

?>
