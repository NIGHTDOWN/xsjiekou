<?php

return array(
    'other' =>
    array(
        'dbhost'=>'ip.ng169.com:3806',
                'dbname'=>'Novel2',
                'dbuser'=>'root',
                'dbpwd'=>'y6155286',
                'dbpre'=>'tp_',
                'charset'=>'utf8'
        // 'dbhost' => '127.0.0.1',
        // 'dbname' => 'copy_f_server',
        // 'dbuser' => 'newtmp',
        // 'dbpwd' => 'newtmp',
        // 'dbpre' => 'tp_',
        // 'charset' => 'utf8'
    ),
    'main' =>
    array(
        'dbhost'=>'ip.ng169.com:3806',
                'dbname'=>'xs_cn',
                'dbuser'=>'ng169',
                'dbpwd'=>'y6155286',
                'dbpre'=>'tp_',
                'charset'=>'utf8'
    ), 
    //内容库
    'content' =>
    array(
        'dbhost'=>'ip.ng169.com:3806',
                'dbname'=>'xs_cn',
                'dbuser'=>'ng169',
                'dbpwd'=>'y6155286',
                'dbpre'=>'tp_',
                'charset'=>'utf8'
    )
);
