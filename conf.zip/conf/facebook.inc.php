<?php

return array(
            'main'=>
            array(
                'app_id'=>'2090299167929890',//appid
                'app_secret'=>'38dca4e8957b0e7e194849875769abe2',//app_secret
                'LoginUrl'=>'https://192.168.6.6/api/login/fbback',//回调链接
                   
                    )

    );

?>
